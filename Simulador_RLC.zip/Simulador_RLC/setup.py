from setuptools import setup, find_packages

setup(
    name='simulador_rlc',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'numpy', 
        'matplotlib',
        'scipy',
    ],
)

'''
Para instalar:
    -Windows + R
    -cmd
    -cd {ubicación del archivo}
    -pip install .
    -Crear otro archivo .py
    -
        import Simulador_RLC
        from Simulador_RLC.interfaz import App

        app = App()
        app.mainloop()
'''