import tkinter as tk
from tkinter import ttk, messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import numpy as np
from Circuito.componentes import Resistencia, Capacitor, Inductor
from Circuito.fuente import FuenteDC
from Circuito.circuito import Circuito


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Simulador de Circuitos RLC, RL, RC")
        self.geometry("800x600")

        # Variables de entrada
        self.resistencia_var = tk.StringVar()
        self.inductor_var = tk.StringVar()
        self.capacitor_var = tk.StringVar()
        self.configuracion_var = tk.StringVar(value="serie")
        self.duracion_var = tk.StringVar(value="1")
        self.voltaje_var = tk.StringVar(value="10")

        # Crear widgets de entrada
        self._crear_widgets()

        # Área para la gráfica
        self.fig, self.ax = plt.subplots(figsize=(7, 5))
        self.canvas = FigureCanvasTkAgg(self.fig, master=self)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _crear_widgets(self):
        frame = tk.Frame(self)
        frame.pack(pady=10)

        tk.Label(frame, text="Resistencia (Ohm):").grid(row=0, column=0,
                                                        padx=5, pady=5)
        tk.Entry(frame, textvariable=self.resistencia_var).grid(row=0, column=1,
                                                                padx=5, pady=5)

        tk.Label(frame, text="Inductor (H):").grid(row=1, column=0, padx=5,
                                                   pady=5)
        tk.Entry(frame, textvariable=self.inductor_var).grid(row=1, column=1,
                                                             padx=5, pady=5)

        tk.Label(frame, text="Capacitor (F):").grid(row=2, column=0, padx=5,
                                                    pady=5)
        tk.Entry(frame, textvariable=self.capacitor_var).grid(row=2, column=1,
                                                              padx=5, pady=5)

        tk.Label(frame, text="Voltaje Fuente (V):").grid(row=3, column=0,
                                                         padx=5, pady=5)
        tk.Entry(frame, textvariable=self.voltaje_var).grid(row=3, column=1,
                                                            padx=5, pady=5)

        tk.Label(frame, text="Configuración:").grid(row=4, column=0, padx=5,
                                                    pady=5)
        opciones = [("Serie", "serie"), ("Paralelo", "paralelo")]
        col = 1
        for texto, valor in opciones:
            tk.Radiobutton(frame, text=texto, variable=self.configuracion_var,
                           value=valor).grid(row=4, column=col, padx=5, pady=5)
            col += 1

        tk.Label(frame, text="Duración (s):").grid(row=5, column=0, padx=5,
                                                   pady=5)
        tk.Entry(frame, textvariable=self.duracion_var).grid(row=5, column=1,
                                                             padx=5, pady=5)

        tk.Button(frame, text="Simular",
                  command=self.simular).grid(row=6, column=0, columnspan=2, pady=10)

    def simular(self):
        try:
            R_val = float(self.resistencia_var.get())
        except ValueError:
            messagebox.showerror("Error", "Ingrese un valor numérico válido para la Resistencia.")
            return

        try:
            L_val = float(self.inductor_var.get()) if self.inductor_var.get() != "" else None
        except ValueError:
            messagebox.showerror("Error", "Ingrese un valor numérico válido para el Inductor.")
            return

        try:
            C_val = float(self.capacitor_var.get()) if self.capacitor_var.get() != "" else None
        except ValueError:
            messagebox.showerror("Error", "Ingrese un valor numérico válido para el Capacitor.")
            return

        try:
            duracion = float(self.duracion_var.get())
        except ValueError:
            messagebox.showerror("Error", "Ingrese un valor numérico válido para la duración.")
            return

        try:
            voltaje = float(self.voltaje_var.get())
        except ValueError:
            messagebox.showerror("Error", "Ingrese un valor numérico válido para el Voltaje de la Fuente.")
            return

        # Crear la fuente DC con el voltaje ingresado
        fuente = FuenteDC(voltaje=voltaje)
        componentes = []
        if R_val:
            componentes.append(Resistencia(valor=R_val))
        if L_val is not None:
            componentes.append(Inductor(valor=L_val))
        if C_val is not None:
            componentes.append(Capacitor(valor=C_val))

        configuracion = self.configuracion_var.get()
        circuito = Circuito(componentes=componentes,
                            configuracion=configuracion, fuente=fuente)

        # Generar vector de tiempo
        t = np.linspace(0, duracion, 500)
        resultados = circuito.simular(t)
        self.graficar(resultados)

    def graficar(self, resultados: dict):
        self.fig.clf()
        tiempo = resultados['Tiempo']

        if self.configuracion_var.get() == "serie":
            ax1 = self.fig.add_subplot(2, 1, 1)
            ax1.plot(tiempo, resultados['Voltaje Fuente'],
                     linestyle='--', color='black', label='Voltaje Fuente')
            ax1.plot(tiempo, resultados['Voltaje Resistencia'],
                     color='green', label='Voltaje Resistencia')
            ax1.plot(tiempo, resultados['Voltaje Inductor'],
                     color='red', label='Voltaje Inductor')
            ax1.plot(tiempo, resultados['Voltaje Capacitor'],
                     color='blue', label='Voltaje Capacitor')
            ax1.set_title("Respuesta de Voltajes en Circuito Serie")
            ax1.set_xlabel("Tiempo (s)")
            ax1.set_ylabel("Voltaje (V)")
            ax1.legend()
            ax1.grid(True)

            ax2 = self.fig.add_subplot(2, 1, 2)
            ax2.plot(tiempo, resultados['Corriente'],
                     color='orange', label='Corriente Circuito')
            ax2.set_title("Respuesta de Corriente en Circuito Serie")
            ax2.set_xlabel("Tiempo (s)")
            ax2.set_ylabel("Corriente (A)")
            ax2.legend()
            ax2.grid(True)
        else:
            ax1 = self.fig.add_subplot(2, 1, 1)
            ax1.plot(tiempo, resultados['Voltaje Nodo'],
                     color='black', label='Voltaje Nodo')
            ax1.set_title("Respuesta de Voltaje en el Nodo (Circuito Paralelo)")
            ax1.set_xlabel("Tiempo (s)")
            ax1.set_ylabel("Voltaje (V)")
            ax1.legend()
            ax1.grid(True)

            ax2 = self.fig.add_subplot(2, 1, 2)
            ax2.plot(tiempo, resultados['Corriente Resistencia'],
                     color='green', label='Corriente Resistencia')
            ax2.plot(tiempo, resultados['Corriente Inductor'],
                     color='red', label='Corriente Inductor')
            ax2.plot(tiempo, resultados['Corriente Capacitor'],
                     color='blue', label='Corriente Capacitor')
            ax2.plot(tiempo, resultados['Corriente Total'],
                     linestyle='--', color='orange', label='Corriente Total')
            ax2.set_title("Respuesta de Corriente (Circuito Paralelo)")
            ax2.set_xlabel("Tiempo (s)")
            ax2.set_ylabel("Corriente (A)")
            ax2.legend()
            ax2.grid(True)

        self.fig.tight_layout()
        self.canvas.draw()