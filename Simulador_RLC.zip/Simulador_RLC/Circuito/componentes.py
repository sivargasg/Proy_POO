class Resistencia:
    def __init__(self, valor):
        if valor <= 0:
            raise ValueError("La resistencia debe ser mayor que cero.")
        self.valor = valor  # Valor en Ohmios

class Inductor:
    def __init__(self, valor):
        if valor <= 0:
            raise ValueError("El inductor debe ser mayor que cero.")
        self.valor = valor  # Valor en Henrios

class Capacitor:
    def __init__(self, valor):
        if valor <= 0:
            raise ValueError("El capacitor debe ser mayor que cero.")
        self.valor = valor  # Valor en Faradios