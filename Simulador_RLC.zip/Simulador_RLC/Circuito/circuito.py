from scipy.integrate import solve_ivp
import numpy as np
from .fuente import FuenteDC
from .componentes import Resistencia, Inductor, Capacitor


class Circuito:
    def __init__(self, componentes: list, configuracion: str, fuente: FuenteDC):
        """
        componentes: lista de instancias de Resistencia, Inductor y/o Capacitor.
        configuracion: 'serie' o 'paralelo'
        fuente: instancia de FuenteDC.
        """
        self.componentes = componentes
        self.configuracion = configuracion.lower()
        self.fuente = fuente

    def simular(self, tiempo: np.ndarray):
        if self.configuracion == "serie":
            return self._simular_serie(tiempo)
        elif self.configuracion == "paralelo":
            return self._simular_paralelo(tiempo)
        else:
            raise ValueError("Configuración no soportada. Use 'serie' o 'paralelo'.")

    def _simular_serie(self, tiempo: np.ndarray):
        R = next((c for c in self.componentes if isinstance(c, Resistencia)), None)
        L = next((c for c in self.componentes if isinstance(c, Inductor)), None)
        C = next((c for c in self.componentes if isinstance(c, Capacitor)), None)
        V_s = self.fuente.entregar_tension(tiempo)
        V0 = V_s[0]

        # Por defecto se ponen todos los valores como cero
        I = np.zeros_like(tiempo)
        V_R = np.zeros_like(tiempo)
        V_L = np.zeros_like(tiempo)
        V_C = np.zeros_like(tiempo)
        
        if (C is not None) and (L is None):
            def ecuacion_RC(t, Vc):
                # Esta es la ecuación del diferencial de Vc sacada con un análisis al circuito  
                return (V0 - Vc) / (R.valor * C.valor)
            # Aqui se resuelve la ecuación anterior con una integral y un valor inicial
            sol = solve_ivp(ecuacion_RC, (tiempo[0], tiempo[-1]), [0], t_eval=tiempo)
            V_C = sol.y[0]
            # La corriente del circuito es la derivada de Vc por la capacitancia
            I = C.valor * np.gradient(V_C, tiempo)
            V_R = V_s - V_C

        elif (L is not None) and (C is None):
            def ecuacion_RL(t, I_val):
                return (V0 - R.valor * I_val) / L.valor
            sol = solve_ivp(ecuacion_RL, (tiempo[0], tiempo[-1]), [0], t_eval=tiempo)
            I = sol.y[0]
            V_R = R.valor * I
            V_L = V_s - V_R

        elif (L is not None) and (C is not None):
            def sistema_RLC(t, Y):
                ''' 
                "Y" es un vector que tiene dos ecuaciones: 
                la del diferencial de la corriente del inductor y la del diferencial 
                de voltaje del capacitor
                '''
                I_val, Vc = Y
                dIdt = (V0 - R.valor * I_val - Vc) / L.valor
                dVcdt = I_val / C.valor
                return [dIdt, dVcdt]
            sol = solve_ivp(sistema_RLC, (tiempo[0], tiempo[-1]), [0, 0], t_eval=tiempo)
            I = sol.y[0]
            V_C = sol.y[1]
            V_R = R.valor * I
            V_L = V_s - V_R - V_C
        
        elif (L is None) and (C is None) and (R is not None):
            I = np.full_like(tiempo, V0 / R.valor)
            V_R = np.full_like(tiempo, V0)
            
        else:
            raise ValueError("Para serie se requiere al menos una Resistencia, un Inductor y/o Capacitor. También se puede una Resistencia")

        resultados = {
            'Tiempo': tiempo,
            'Voltaje Fuente': V_s,
            'Corriente': I,
            'Voltaje Resistencia': V_R,
            'Voltaje Inductor': V_L,
            'Voltaje Capacitor': V_C
        }
        return resultados

    def _simular_paralelo(self, tiempo: np.ndarray):
        R = next((c for c in self.componentes if isinstance(c, Resistencia)), None)
        L = next((c for c in self.componentes if isinstance(c, Inductor)), None)
        C = next((c for c in self.componentes if isinstance(c, Capacitor)), None)
        V_s = self.fuente.entregar_tension(tiempo)
        V0 = V_s[0]

        V_nodo = np.zeros_like(tiempo)
        I_R = np.zeros_like(tiempo)
        I_C = np.zeros_like(tiempo)
        I_L = np.zeros_like(tiempo)
        I_total = np.zeros_like(tiempo)

        if (C is not None) and (L is None):
            def ecuacion_RC(t, V):
                return (V0 - V) / (R.valor * C.valor)
            sol = solve_ivp(ecuacion_RC, (tiempo[0], tiempo[-1]), [0], t_eval=tiempo)
            V_nodo = sol.y[0]
            I_R = V_nodo / R.valor
            I_C = C.valor * np.gradient(V_nodo, tiempo)
            I_total = I_R + I_C

        elif (L is not None) and (C is None):
            tau = L.valor / R.valor
            I_R0 = V0 / R.valor
            I_L = I_R0 * (1 - np.exp(-tiempo / tau))
            I_R = I_R0 * np.exp(-tiempo / tau)
            I_total = I_R + I_L
            V_nodo = np.full_like(tiempo, V0)

        elif (L is not None) and (C is not None):
            R_s_valor = 1.0  # Resistencia interna de la fuente para permitir el análisis
            def V_fuente(t):
                t_rampa = 0.001  # 1 ms para evitar cambios instantáneos
                return (V0 / t_rampa) * t if t < t_rampa else V0
            def sistema_RLC_par(t, y):
                V, I_L_val = y
                V0_t = V_fuente(t)
                dVdt = ((V0_t - V) / R_s_valor - V / R.valor - I_L_val) / C.valor
                dI_L_dt = V / L.valor
                return [dVdt, dI_L_dt]
            sol = solve_ivp(sistema_RLC_par, (tiempo[0], tiempo[-1]), [0, 0], t_eval=tiempo)
            V_nodo = sol.y[0]
            I_L = sol.y[1]
            I_R = V_nodo / R.valor
            I_C = C.valor * np.gradient(V_nodo, tiempo)
            I_total = I_R + I_C + I_L
        
        elif (L is None) and (C is None) and (R is not None):
            I_total = np.full_like(tiempo, V0 / R.valor)
            V_nodo = np.full_like(tiempo, V0)
            
        else:
            raise ValueError("Para paralelo se requiere al menos una Resistencia, un Inductor y/o Capacitor. También se puede una Resistencia")

        resultados = {
            'Tiempo': tiempo,
            'Voltaje Nodo': V_nodo,
            'Corriente Total': I_total,
            'Corriente Resistencia': I_R,
            'Corriente Inductor': I_L,
            'Corriente Capacitor': I_C
        }
        return resultados