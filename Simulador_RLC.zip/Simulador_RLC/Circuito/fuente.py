import numpy as np


class FuenteDC:
    def __init__(self, voltaje):
        self.voltaje = voltaje  # Voltaje en Voltios

    def entregar_tension(self, tiempo):
        # Devuelve un vector con el escalón DC usando np.
        return np.full_like(tiempo, self.voltaje, dtype=float)